"""
Stage 02 - Data Preprocessing
Defines the PyTorch Dataset, transforms, and DataLoader used by every
downstream stage (segmentation, pose estimation, garment processing, try-on).

Usage:
    python 02_data_preprocessing.py   # quick smoke test on a batch
"""

import os
import glob

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

import config


base_transform = transforms.Compose([
    transforms.Resize((config.IMG_SIZE, config.IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.5] * 3, [0.5] * 3),  # maps to [-1, 1]
])

mask_transform = transforms.Compose([
    transforms.Resize((config.IMG_SIZE, config.IMG_SIZE)),
    transforms.ToTensor(),
])


class VTONDataset(Dataset):
    """
    Paired virtual try-on dataset.

    Each item returns a dict with:
        'person' : (3, H, W) tensor in [-1, 1]
        'cloth'  : (3, H, W) tensor in [-1, 1]
        'mask'   : (1, H, W) tensor in [0, 1]  (only if mask_dir is given and file exists)
        'filename': original filename, useful for pairing with pose json files
    """

    def __init__(
        self,
        cloth_dir=config.CLOTH_DIR,
        person_dir=config.PERSON_DIR,
        mask_dir=config.MASK_DIR,
        transform=base_transform,
        mask_tf=mask_transform,
    ):
        self.cloth_paths = sorted(glob.glob(os.path.join(cloth_dir, "*")))
        self.person_paths = sorted(glob.glob(os.path.join(person_dir, "*")))
        self.mask_dir = mask_dir if os.path.isdir(mask_dir) else None
        self.transform = transform
        self.mask_tf = mask_tf

        if len(self.cloth_paths) == 0:
            raise FileNotFoundError(
                f"No images found in {cloth_dir}. Check config.CLOTH_DIR."
            )
        if len(self.person_paths) != len(self.cloth_paths):
            raise ValueError(
                "cloth and person folders must contain the same number of "
                "paired images for a paired virtual try-on dataset."
            )

    def __len__(self):
        return len(self.cloth_paths)

    def __getitem__(self, idx):
        cloth_path = self.cloth_paths[idx]
        person_path = self.person_paths[idx]

        cloth_img = Image.open(cloth_path).convert("RGB")
        person_img = Image.open(person_path).convert("RGB")

        item = {
            "cloth": self.transform(cloth_img),
            "person": self.transform(person_img),
            "filename": os.path.basename(person_path),
        }

        if self.mask_dir:
            mask_path = os.path.join(self.mask_dir, os.path.basename(person_path))
            if os.path.exists(mask_path):
                mask_img = Image.open(mask_path).convert("L")
                item["mask"] = self.mask_tf(mask_img)

        return item


def get_dataloader(dataset=None, batch_size=config.BATCH_SIZE, shuffle=True):
    if dataset is None:
        dataset = VTONDataset()
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=config.NUM_WORKERS,
        drop_last=True,
    )


def denormalize(tensor):
    """Converts a [-1, 1] image tensor back to [0, 1] for visualization/saving."""
    return (tensor.clamp(-1, 1) + 1) / 2


if __name__ == "__main__":
    dataset = VTONDataset()
    print(f"Dataset size: {len(dataset)}")

    loader = get_dataloader(dataset)
    batch = next(iter(loader))
    print("person batch shape:", batch["person"].shape)
    print("cloth batch shape :", batch["cloth"].shape)
    if "mask" in batch:
        print("mask batch shape  :", batch["mask"].shape)
