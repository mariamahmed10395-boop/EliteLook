"""
Shared configuration for the Virtual Try-On computer vision pipeline.
Every stage (01-10) imports its paths and hyperparameters from here.
"""

import os
import torch

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

DATA_ROOT = "/content/data"                 # where the Kaggle dataset is unzipped
CHECKPOINT_DIR = os.path.join(PROJECT_ROOT, "checkpoints")
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "outputs")
LOG_DIR = os.path.join(PROJECT_ROOT, "logs")

os.makedirs(CHECKPOINT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# Dataset sub-folders. These are best guesses based on the Kaggle dataset
# description ("garments and individuals wearing them" + masks + OpenPose).
# Run 01_data_loading.py's inspect_dataset() first and update these if the
# real folder names differ.
CLOTH_DIR = os.path.join(DATA_ROOT, "cloth")
PERSON_DIR = os.path.join(DATA_ROOT, "person")
MASK_DIR = os.path.join(DATA_ROOT, "mask")
POSE_DIR = os.path.join(DATA_ROOT, "pose")

KAGGLE_DATASET_SLUG = "adarshsingh0903/virtual-tryon-dataset"

# ---------------------------------------------------------------------------
# General settings
# ---------------------------------------------------------------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42

IMG_SIZE = 256
BATCH_SIZE = 8
NUM_WORKERS = 2

# ---------------------------------------------------------------------------
# Training hyperparameters per stage
# ---------------------------------------------------------------------------
SEGMENTATION_EPOCHS = 20
SEGMENTATION_LR = 1e-4

POSE_EPOCHS = 15
POSE_LR = 1e-3
NUM_KEYPOINTS = 18

GARMENT_WARP_EPOCHS = 15
GARMENT_WARP_LR = 1e-4
TPS_GRID_SIZE = 5

TRYON_EPOCHS = 50
TRYON_LR = 2e-4
L1_LOSS_WEIGHT = 100

CLASSIFIER_EPOCHS = 10
CLASSIFIER_LR = 1e-3
NUM_GARMENT_CLASSES = 5
