"""
Stage 01 - Data Loading
Downloads the Kaggle Virtual Try-On dataset and inspects its folder structure.

Dataset: https://www.kaggle.com/datasets/adarshsingh0903/virtual-tryon-dataset

Usage:
    python 01_data_loading.py
"""

import os
import subprocess
import config


def download_dataset(dest=config.DATA_ROOT, slug=config.KAGGLE_DATASET_SLUG):
    """
    Downloads and unzips the dataset using the Kaggle CLI.
    Requires ~/.kaggle/kaggle.json to be present (Kaggle API token).
    """
    os.makedirs(dest, exist_ok=True)

    if os.listdir(dest):
        print(f"[download_dataset] '{dest}' is not empty, skipping download.")
        return

    cmd = [
        "kaggle", "datasets", "download",
        "-d", slug,
        "-p", dest,
        "--unzip",
    ]
    print(f"[download_dataset] Running: {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    print("[download_dataset] Done.")


def inspect_dataset(root=config.DATA_ROOT, max_depth=3, sample_files=5):
    """
    Walks the dataset directory and prints its structure so the real folder
    names/formats can be confirmed and config.py updated if needed.
    """
    if not os.path.exists(root):
        print(f"[inspect_dataset] '{root}' does not exist. Run download_dataset() first.")
        return

    for current_root, dirs, files in os.walk(root):
        depth = current_root.replace(root, "").count(os.sep)
        if depth > max_depth:
            continue

        indent = "  " * depth
        print(f"{indent}{os.path.basename(current_root) or current_root}/")

        sub_indent = "  " * (depth + 1)
        for f in sorted(files)[:sample_files]:
            print(f"{sub_indent}{f}")
        if len(files) > sample_files:
            print(f"{sub_indent}... ({len(files)} files total)")


def count_files_per_folder(root=config.DATA_ROOT):
    """Returns a dict {folder_path: file_count} for quick sanity checks."""
    counts = {}
    for current_root, _, files in os.walk(root):
        if files:
            counts[current_root] = len(files)
    return counts


if __name__ == "__main__":
    download_dataset()
    print("\n--- Dataset structure ---")
    inspect_dataset()

    print("\n--- File counts per folder ---")
    for folder, n in count_files_per_folder().items():
        print(f"{folder}: {n} files")
