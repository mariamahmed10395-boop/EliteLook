# Virtual Try-On Computer Vision Pipeline

Dataset: [adarshsingh0903/virtual-tryon-dataset](https://www.kaggle.com/datasets/adarshsingh0903/virtual-tryon-dataset) (Kaggle)

## Pipeline

```
User Images
    |
    v
01 Data Loading
    |
    v
02 Preprocessing
    |
    v
03 Segmentation
    |
    v
04 Pose Estimation
    |
    v
05 Body Analysis
    |
    v
06 Garment Processing
    |
    v
07 Virtual Try-On
    |
    v
08 Model Training (development only)
    |
    v
09 Evaluation
    |
    v
10 Inference -> Final Result
```

## Setup

```bash
pip install -r requirements.txt
```

Kaggle API credentials are required for stage 01: place your `kaggle.json`
token in `~/.kaggle/kaggle.json` (or upload it in Colab before running).

## Important: verify the dataset folder names first

Run stage 01 first and read its printed folder tree:

```bash
python 01_data_loading.py
```

Then open `config.py` and update `CLOTH_DIR`, `PERSON_DIR`, `MASK_DIR`,
`POSE_DIR` to match the real folder names shown by that inspection — they
are currently best guesses (`cloth/`, `person/`, `mask/`, `pose/`).

## Running the full pipeline

```bash
python run_pipeline.py
```

Or run/debug each stage independently:

```bash
python 03_segmentation.py
python 04_pose_estimation.py
python 06_garment_processing.py
python 08_model_training.py
python 09_model_evaluation.py --checkpoint checkpoints/tryon_latest.pth
python 10_inference.py --person my_person.jpg --cloth my_cloth.jpg
```

## File overview

| File                        | Purpose                                                        |
|------------------------------|------------------------------------------------------------------|
| `config.py`                  | Shared paths and hyperparameters for every stage                |
| `01_data_loading.py`         | Downloads dataset from Kaggle, inspects folder structure         |
| `02_data_preprocessing.py`   | `VTONDataset`, transforms, `DataLoader`                          |
| `03_segmentation.py`         | U-Net body/cloth segmentation model + training loop               |
| `04_pose_estimation.py`      | MediaPipe keypoint extraction + trainable CNN pose regressor      |
| `05_body_analysis.py`        | Derives body measurements (height, shoulder/waist/hip width) from mask + keypoints |
| `06_garment_processing.py`   | Garment classifier (+ KMeans fallback) and TPS-based cloth warper |
| `07_virtual_tryon.py`        | Pix2Pix generator, PatchGAN discriminator, full `VirtualTryOnPipeline` |
| `08_model_training.py`       | End-to-end adversarial training of the full pipeline              |
| `09_model_evaluation.py`     | L1 / PSNR / SSIM metrics on a trained checkpoint                  |
| `10_inference.py`            | Runs a trained model on a single person/cloth pair -> saved image |
| `run_pipeline.py`            | Convenience script to run all stages in order                     |

## Notes

- All models here are lightweight, educational implementations meant to run
  end-to-end on a single GPU (e.g. Colab T4). For research-grade quality
  closer to CP-VTON / VITON-HD, increase model capacity, train for more
  epochs, and replace the simplified TPS grid generator with a full
  closed-form thin-plate-spline solver.
- `05_body_analysis.py` measurements are in pixel space by default; use
  `pixels_to_cm()` with a calibrated reference height for real-world units.
